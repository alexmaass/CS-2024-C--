/*
 * minithread.c:
 *	This file provides a few function headers for the procedures that
 *	you are required to implement for the minithread assignment.
 *
 *	EXCEPT WHERE NOTED YOUR IMPLEMENTATION MUST CONFORM TO THE
 *	NAMING AND TYPING OF THESE PROCEDURES.
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include "minithread.h"
#include "queue.h"
#include "synch.h"

/*
 * A minithread should be defined either in this file or in a private
 * header file.  Minithreads have a stack pointer with to make procedure
 * calls, a stackbase which points to the bottom of the procedure
 * call stack, the ability to be enqueueed and dequeued, and any other state
 * that you feel they must have.
 */
struct minithread {
	int tid;
	stack_pointer_t sp;				// stack pointer
	stack_pointer_t bsp;			// base stack pointer
	void* prev;
	void* next;
};

/* minithread functions */

/*
 *	Function that cleans up minithreads. It goes through each 
 *	minithread in the clean up queue and deletes that minithread. 
 *	It calls semaphoreP on the cleanup semaphore after each thread
 *	it cleans up. Once all of the threads have been cleaned up,
 *	the cleanup semaphore should block the thread until semaV is
 *  called by a thread's final proc. 
 */
void minithread_cleanup(arg_t t) {
	// Call semaphore_P at creation to get thrown onto the blocked queue of the semaphore. 
	semaphore_P(cleanupSem);
	while(1){
		while(queue_length(cleanupQueue) > 0){
			minithread_t cleanupThread = NULL;
			queue_dequeue(cleanupQueue, (void**)cleanupThread);
			// Cleanup the cleanupThread.
			cleanupThread -> next = NULL;
			cleanupThread -> prev = NULL;
			cleanupThread -> tid = 0;
			minithread_free_stack(cleanupThread->bsp);
			free(cleanupThread);
			// Call semaphore_P to signal a thread has been cleaned up. 
			semaphore_P(cleanupSem);
		}
	}
}

/*
 *	The final commands that each minithread executes when it terminates.
 *	The currently running thread is moved to the clean up queue, the head
 *	of the ready queue is context switched into, and the cleanup thread is
 *	signals by the cleanup semaphore. 
 */
void minithread_final(arg_t arg){
	minithread_t curThread = NULL;
	minithread_t newThread = NULL;
	// Set the runningThread to the end of the cleanup queue. 
	curThread = runningThread;
	queue_append(cleanupQueue, curThread);
	// Set the first thread in the ready queue as the running thread. 
	queue_dequeue(readyQueue, (void**)newThread);
	runningThread = newThread;
	// Do context switching with the stacks. 
	minithread_switch(&(curThread->sp), &(newThread->sp));
	// Signal the cleanup thread to start running. 
	semaphore_V(cleanupSem);
}

/*
 *	Does the same thing as minithread create except that the created
 *	thread is also scheduled on the ready queue. 
 */
minithread_t minithread_fork(proc_t proc, arg_t arg) {
	minithread_t newThread = minithread_create(proc, arg);
	//put thread in ready queue.
	queue_append(readyQueue, newThread);
	return newThread;
}

/*
 *	Creates a new minithread. It allocates new memory for the minithread,
 *	allocated memory for the stack space, and initializes the stack space
 *	and other variables. The thread is not enqueued in the ready queue. 
 */
minithread_t minithread_create(proc_t proc, arg_t arg) {
	void (*final_proc)(arg_t);
	int final_arg = 0;
	// Allocate memory for the new minithread. 
	minithread_t newThread = (minithread_t) malloc(sizeof(struct minithread));
	if (newThread == NULL){
		return NULL;
	}
	else{
		// Allocate stack space for the new minithread. 
		minithread_allocate_stack(&(newThread->bsp), &(newThread->sp));
		//generate thread id
		(newThread -> tid) = minithread_assignID();
		//prepare arguments for initalize stack function
		final_proc = minithread_final;
		minithread_initialize_stack(&(newThread->sp), proc, arg, (proc_t)final_proc, (arg_t)final_arg);

		return newThread;
	}
}

/*
 *	Returns the currently running thread. 
 */
minithread_t minithread_self() {
	if(runningThread != NULL){
		return runningThread;
	}
	else{ 
		return NULL;
	}
}

/*
 *	Returns the ID of the currently running thread. 
 */
int minithread_id() {
	if(minithread_self() != NULL){
		return minithread_self() -> tid;
	}
	else{
		return -1;
	}
}

/*
 *	Stops running the currently running thread and moves it to the cleanup
 *	queue. It then context switches into the ready process. 
 */
void minithread_stop() {
	minithread_t curThread = NULL;
	minithread_t newThread = NULL;

	// Enqueues the currently running thread in the clean up queue. 
	curThread = runningThread;
	queue_append(cleanupQueue, curThread);
	
	// Dequeues the head of the ready queue and begins executing that thread. 
	queue_dequeue(readyQueue, (void**)newThread);
	runningThread = newThread;

	// Context switch from the previous thread to the new running thread. 
	minithread_switch(&(curThread->sp), &(newThread->sp));
}

/*
 *	Starts the minithread by moving the minithread to the ready queue. 
 */
void minithread_start(minithread_t t) {
	queue_append(readyQueue, (void*)t);
}

/*
 *	Moves the currently running thread to the end of the ready queue and context
 *	switches the head of the ready queue into the running thread. 
 */
void minithread_yield() {
	minithread_t curThread = NULL;
	minithread_t newThread = NULL;
	// Logic is: takeout the thread in running queue, put it onto the ready queue
	// take out the thread in ready queue, put it onto the running queue ( run the thread)
	curThread = minithread_self();
	queue_dequeue(readyQueue, (void**)&newThread); 
	if(newThread == NULL){
		return;
	}
	else{
		queue_append(readyQueue, curThread);
		runningThread = newThread;
		// switch the two stack pointers
		minithread_switch(&(curThread -> sp), &(newThread -> sp));	
	}
}

/* 
 * Initialization.
 *
 * 	minithread_system_initialize:
 *	 This procedure should be called from your C main procedure
 *	 to turn a single threaded UNIX process into a multithreaded
 *	 program.
 *
 *	 Initialize any private data structures.
 * 	 Create the idle thread.
 *       Fork the thread which should call mainproc(mainarg)
 * 	 Start scheduling.
 */
void minithread_system_initialize(proc_t mainproc, arg_t mainarg){
	// Declare all of the variables. 
	void (*cleanup_proc)(arg_t);
	int cleanup_arg = 0;

	// Initialize variables 
	runningThread =  (minithread_t) malloc(sizeof(struct minithread));
	if (runningThread == NULL){
		return;
	}
	else{
		(runningThread -> tid) = 0;
		(runningThread -> sp) = NULL;				// stack pointer
		(runningThread -> bsp) = NULL;				// base stack pointer
		(runningThread -> prev) = NULL;
		(runningThread -> next) = NULL;
	}
	thread_id = 0;
	cleanupQueue = queue_new();
	readyQueue = queue_new();

	// init the semaphore
	cleanupSem = semaphore_create();
	semaphore_initialize(cleanupSem, 0);

	// init the cleanup thread
	cleanup_proc = minithread_cleanup;
//	cleanupThread= minithread_fork((proc_t)cleanup_proc, NULL);

	// Create the main process thread. 
	minithread_fork(mainproc, mainarg);

	// Use this thread as the idle thread.
	while(1){
		minithread_yield();
	}
}


/*
 *	Increments the thread ID and returns the value. 
 */
int minithread_assignID(){
	thread_id++;
	return thread_id;
}